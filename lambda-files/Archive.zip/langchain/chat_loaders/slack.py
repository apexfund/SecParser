from langchain_community.chat_loaders.slack import SlackChatLoader

__all__ = ["SlackChatLoader"]
