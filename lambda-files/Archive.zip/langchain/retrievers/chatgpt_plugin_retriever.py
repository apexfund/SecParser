from langchain_community.retrievers.chatgpt_plugin_retriever import (
    ChatGPTPluginRetriever,
)

__all__ = ["ChatGPTPluginRetriever"]
