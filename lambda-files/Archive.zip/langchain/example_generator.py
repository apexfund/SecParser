"""Keep here for backwards compatibility."""
from langchain.chains.example_generator import generate_example

__all__ = ["generate_example"]
