from langchain_community.embeddings.johnsnowlabs import JohnSnowLabsEmbeddings

__all__ = ["JohnSnowLabsEmbeddings"]
