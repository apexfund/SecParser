from langchain_community.embeddings.voyageai import (
    VoyageEmbeddings,
)

__all__ = [
    "VoyageEmbeddings",
]
