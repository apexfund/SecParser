from langchain_community.embeddings.cohere import CohereEmbeddings

__all__ = ["CohereEmbeddings"]
