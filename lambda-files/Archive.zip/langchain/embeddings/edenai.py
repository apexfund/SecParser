from langchain_community.embeddings.edenai import EdenAiEmbeddings

__all__ = ["EdenAiEmbeddings"]
