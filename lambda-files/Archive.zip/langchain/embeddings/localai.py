from langchain_community.embeddings.localai import (
    LocalAIEmbeddings,
)

__all__ = [
    "LocalAIEmbeddings",
]
