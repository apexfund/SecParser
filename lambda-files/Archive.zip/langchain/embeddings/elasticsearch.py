from langchain_community.embeddings.elasticsearch import ElasticsearchEmbeddings

__all__ = ["ElasticsearchEmbeddings"]
