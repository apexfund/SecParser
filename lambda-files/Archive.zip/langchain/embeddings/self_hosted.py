from langchain_community.embeddings.self_hosted import (
    SelfHostedEmbeddings,
)

__all__ = ["SelfHostedEmbeddings"]
