from langchain_community.embeddings.octoai_embeddings import (
    OctoAIEmbeddings,
)

__all__ = ["OctoAIEmbeddings"]
