from langchain_community.embeddings.deepinfra import (
    DeepInfraEmbeddings,
)

__all__ = ["DeepInfraEmbeddings"]
