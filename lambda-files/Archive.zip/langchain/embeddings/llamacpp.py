from langchain_community.embeddings.llamacpp import LlamaCppEmbeddings

__all__ = ["LlamaCppEmbeddings"]
