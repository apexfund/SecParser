from langchain_community.embeddings.baidu_qianfan_endpoint import (
    QianfanEmbeddingsEndpoint,
)

__all__ = ["QianfanEmbeddingsEndpoint"]
