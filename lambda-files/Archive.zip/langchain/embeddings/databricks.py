from langchain_community.embeddings.databricks import DatabricksEmbeddings

__all__ = ["DatabricksEmbeddings"]
