from langchain_community.embeddings.tensorflow_hub import (
    TensorflowHubEmbeddings,
)

__all__ = ["TensorflowHubEmbeddings"]
