from langchain_community.embeddings.ollama import OllamaEmbeddings

__all__ = ["OllamaEmbeddings"]
