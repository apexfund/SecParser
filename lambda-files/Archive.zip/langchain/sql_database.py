"""Keep here for backwards compatibility."""
from langchain_community.utilities.sql_database import SQLDatabase

__all__ = ["SQLDatabase"]
