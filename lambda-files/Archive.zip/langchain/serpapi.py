"""For backwards compatibility."""
from langchain_community.utilities.serpapi import SerpAPIWrapper

__all__ = ["SerpAPIWrapper"]
